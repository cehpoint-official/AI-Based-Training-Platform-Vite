//BRAND
export const name = "Cehpoint E-Learning AI Solutions";
export const company = "Cehpoint E-Learning & Cybersecurity AI Solutions";
export const websiteURL = "https://ai-based-training-platfo-ca895.web.app";
export const logo =
  "https://firebasestorage.googleapis.com/v0/b/ai-based-training-platfo-ca895.appspot.com/o/ai-technology.png?alt=media&token=6d27fd25-93e6-4b0e-b39e-3228e82668b6";

// export const razorpayEnabled = true;
// export const paypalEnabled = true;`
// export const StripeEnabled = true;
// export const paystackEnabled = true;

//PRICING :-

//FREE
// export const FreeType = 'Free Plan';
// export const FreeCost = 0;
// export const FreeTime = '';

// //MONTHLY
// export const MonthType = 'Monthly Plan';
// export const MonthCost = 9;
// export const MonthTime = 'month';

// //YEARLY
// export const YearType = 'Yearly Plan';
// export const YearCost = 99;
// export const YearTime = 'year';

//TESTIMONIAL
export const review =
  "The AI Course Generator revolutionized my content creation process, providing accurate and relevant topics effortlessly. It's a time-saving powerhouse that enhances the quality and relevance of my courses. A must-have tool for educators seeking efficiency and impactful online learning experiences.";
// from and profession is updated

export const from = "Jit Banerjee (Officially Sujan Banerjee )";
export const profession = "Founder & CEO at Cehpoint";
export const photoURL =
  "https://play-lh.googleusercontent.com/sV_ffBmBJt_je4RZHnfaCfcnL-Hy6C14Iol7H5EMj9fzI2GDOonuojdn5t9p6n9IAX8j";

//PAYPAL
// export const paypalPlanIdOne = "P-1EM732768S920784HMWKW3OA";
// export const paypalPlanIdTwo = "P-8T744865W27080359MWOCE5Q";

// //RAZORPAY
// export const razorpayKeyId = "rzp_test_uqALjZHyTyuiOm";
// export const razorpayPlanIdOne = "plan_NMvvtDfznbRp6V";
// export const razorpayPlanIdTwo = "plan_NMRc9HARBQRLWA";

//PhonePe
// export const PhonePe PlanIdOne = "price_1OTo7CSDXmLtVnVeaHIHxqCj";
// export const PhonePe PlanIdTwo = "price_1OTo7eSDXmLtVnVeBbn82U5B";

//PAYSTACK
// export const paystackPlanIdOne = "PLN_ouqmm8eo6i2k9k8";
// export const paystackPlanIdTwo = "PLN_1v1xqb8io9t5lis";
// export const amountInZarOne = '170';
// export const amountInZarTwo = '1871';

// //Phonepay
// export const StripePlanIdOne = "P-1EM732768S920784HMWKW3OA";
// export const StripePlanIdTwo = "P-8T744865W27080359MWOCE5Q";
